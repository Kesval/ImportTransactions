﻿using System;

namespace TransactionData
{
    public class ErrorLog
    {
        public int Id { get; set; }
        public string Account { get; set; }
        public string Description { get; set; }
        public string CurrencyCode { get; set; }
        public string Amount { get; set; }
        public string Error { get; set; }
        public DateTime DateCreated { get; set; }
    }
}
