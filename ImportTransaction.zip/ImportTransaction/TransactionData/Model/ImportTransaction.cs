﻿using System;


namespace TransactionData
{
    public class ImportTransaction
    {
        public int Id { get; set; }
        public string Account { get; set; }
        public string Description { get; set; }
        public string CurrencyCode { get; set; }
        public decimal Amount { get; set; }
        public DateTime DateImported { get; set; }
    }
}
