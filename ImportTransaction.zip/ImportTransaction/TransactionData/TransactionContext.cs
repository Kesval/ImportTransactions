﻿using System.Data.Entity;

namespace TransactionData
{
    public class TransactionContext: DbContext
    {
        public TransactionContext() : base(ConfigProvider.GetTransactionConnectionString())
        {
            //Make sure that we do not create a new database or any new tables/columns 
            Database.SetInitializer<TransactionContext>(null);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new ImportTransactionConfiguration());
            modelBuilder.Configurations.Add(new ErrorLogConfiguration());
            
        }

        //Pluralise the models
        public virtual DbSet<ImportTransaction> ImportTransactions { get; set; }
        public virtual DbSet<ErrorLog> ErrorLogs { get; set; }
    }
}
