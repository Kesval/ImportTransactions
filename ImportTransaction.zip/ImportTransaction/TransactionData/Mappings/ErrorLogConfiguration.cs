﻿using System.Data.Entity.ModelConfiguration;

namespace TransactionData
{
    public class ErrorLogConfiguration : EntityTypeConfiguration<ErrorLog>
    {
        public ErrorLogConfiguration()
        {
            ToTable("ErrorLog");

            HasKey(hk => hk.Id)
                .Property(p => p.Id);

            Property(p => p.Id)
              .HasColumnName("Id")
              .IsRequired();

            Property(p => p.Account)
                .HasColumnName("Account");

            Property(p => p.Description)
                .HasColumnName("Description");

            Property(p => p.CurrencyCode)
                .HasColumnName("CurrencyCode");

            Property(p => p.Amount)
                .HasColumnName("Amount");

            Property(p => p.Error)
                .HasColumnName("Error");

            Property(p => p.DateCreated)
                .HasColumnName("DateCreated");
        }
    }
}
