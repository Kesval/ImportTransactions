﻿using System.Configuration;

namespace TransactionData
{
    public class ConfigProvider
    {
        public static string GetTransactionConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["TransactionDbContext"].ConnectionString;
        }
    }
}
