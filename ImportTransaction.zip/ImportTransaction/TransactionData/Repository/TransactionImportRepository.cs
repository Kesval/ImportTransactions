﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;

namespace TransactionData
{
    public class TransactionImportRepository:ITransactionImportRepository
    {

        private TransactionContext _transactionContext;

        private TransactionContext TransactionContext
        {
            get { return _transactionContext ?? (_transactionContext = new TransactionContext()); }
        }



        public ImportTransaction GetImportTransactionId(int id)
        {
            ImportTransaction importTransaction;

            try
            {
                importTransaction = TransactionContext.ImportTransactions.Find(id);
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return importTransaction;
        }

        public IList<ImportTransaction> GetAllImportTransactions()
        {
            IList<ImportTransaction> returnImportTransactions;

            try
            {
                var importTransactions = from importTransaction in TransactionContext.ImportTransactions
                                         select importTransaction;

                returnImportTransactions = importTransactions.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return returnImportTransactions;
        }

        public IList<ImportTransaction> GetImportTransactionsByDate(DateTime dateTime)
        {
            IList<ImportTransaction> returnImportTransactions;

            try
            {
                var importTransactions = from importTransaction in TransactionContext.ImportTransactions
                                         where importTransaction.DateImported == dateTime
                                         select importTransaction;

                returnImportTransactions = importTransactions.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return returnImportTransactions;
        }

        public IList<ImportTransaction> GetImportTransactionByAccount(string account)
        {
            IList<ImportTransaction> returnImportTransactions;

            try
            {
                var importTransactions = from importTransaction in TransactionContext.ImportTransactions
                                         where importTransaction.Account == account
                                         select importTransaction;

                returnImportTransactions = importTransactions.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return returnImportTransactions;
        }

        public ErrorLog GetErrorLogId(int id)
        {
            ErrorLog errorLog;

            try
            {
                errorLog = TransactionContext.ErrorLogs.Find(id);
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return errorLog;
        }

        public IList<ErrorLog> GetAllErrorLogs()
        {
            IList<ErrorLog> returnErrorLogs;

            try
            {
                var errorLogs = from errorLog in TransactionContext.ErrorLogs
                                select errorLog;

                returnErrorLogs = errorLogs.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return returnErrorLogs;
        }

        public IList<ErrorLog> GetErrorLogByDate(DateTime dateTime)
        {
            IList<ErrorLog> returnErrorLogs;

            try
            {
                var errorLogs = from errorLog in TransactionContext.ErrorLogs
                                where errorLog.DateCreated == dateTime
                                select errorLog;

                returnErrorLogs = errorLogs.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return returnErrorLogs;
        }

        public IList<ErrorLog> GetErrorLogByAccount(string account)
        {
            IList<ErrorLog> returnErrorLogs;

            try
            {
                var errorLogs = from errorLog in TransactionContext.ErrorLogs
                                where errorLog.Account == account
                                select errorLog;

                returnErrorLogs = errorLogs.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return returnErrorLogs;
        }

        


        

        public void Save(ImportTransaction importTransaction)
        {
            try
            {
                if (importTransaction.Id == 0)
                {
                    TransactionContext.ImportTransactions.Add(importTransaction);
                }
                else
                {
                    if (TransactionContext.Entry(importTransaction).State == EntityState.Detached)
                    {
                        TransactionContext.ImportTransactions.Attach(importTransaction);
                    }
                    TransactionContext.Entry(importTransaction).State = EntityState.Modified;
                }
                TransactionContext.SaveChanges();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public void Save(ErrorLog errorLog)
        {
            try
            {
                
                if (errorLog.Id == 0)
                {
                    TransactionContext.ErrorLogs.Add(errorLog);
                }
                else
                {
                    if (TransactionContext.Entry(errorLog).State == EntityState.Detached)
                    {
                        TransactionContext.ErrorLogs.Attach(errorLog);
                    }
                    TransactionContext.Entry(errorLog).State = EntityState.Modified;
                }
                
                TransactionContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Dispose()
        {
            if (_transactionContext != null)
            {
                _transactionContext.Dispose();
                _transactionContext = null;
            }
        }
    }
}
