﻿using System;
using System.Collections.Generic;


namespace TransactionData
{
    public interface ITransactionImportRepository : IDisposable
    {
        ImportTransaction GetImportTransactionId(int id);
        IList<ImportTransaction> GetAllImportTransactions();
        IList<ImportTransaction> GetImportTransactionsByDate(DateTime dateTime);
        IList<ImportTransaction> GetImportTransactionByAccount(string account);

        ErrorLog GetErrorLogId(int id);
        IList<ErrorLog> GetAllErrorLogs();
        IList<ErrorLog> GetErrorLogByDate(DateTime dateTime);
        IList<ErrorLog> GetErrorLogByAccount(string account);

        //Overload Save method
        void Save(ImportTransaction importTransaction);
        void Save(ErrorLog errorLog);
    }
}
