﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ImportTransaction
{
    public class Transaction
    {
        public int CurrentPage { get; set; }
        public int LastPage { get; set; }
        public int TotalNumberFound { get; set; }
        public IList<TransactionRecord> Transactions { get; set; }
    }


    public class Error
    {
        public int CurrentPage { get; set; }
        public int LastPage { get; set; }
        public int TotalNumberFound { get; set; }
        public IList<ErrorRecord> Errors { get; set; }
    }

    public class TransactionRecord
    {
        public int Id { get; set; }
        public string Account { get; set; }
        public string Description { get; set; }
        public string CurrencyCode { get; set; }
        public string Amount { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime DateImported { get; set; }
    }

    public class ErrorRecord
    {
        public int Id { get; set; }
        public string Account { get; set; }
        public string Description { get; set; }
        public string CurrencyCode { get; set; }
        public string Amount { get; set; }
        public string Error { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime DateImported { get; set; }
    }


}