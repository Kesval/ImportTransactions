﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OfficeOpenXml;
using System.IO;
using TransactionData;

namespace ImportTransaction.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "HELLO";
            ViewBag.RowsImported = 0;
            ViewBag.ErrorsImported = 0;
            return View();
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase fileUpload)
        {
            //first save file to server
            if(fileUpload != null)
            {
                string[] path = fileUpload.FileName.Split('\\');
                int count = path.Length;
                string actualFileName = path[count - 1];
                int rowsImported = 0;
                int errorsImported = 0;

                string savePath = Server.MapPath("~/File/");
                ViewBag.Message = savePath;
                //save the file to server
                string newPathFileName = savePath + actualFileName;

                if (System.IO.File.Exists(newPathFileName))
                {
                    System.IO.File.Delete(newPathFileName);
                }

                fileUpload.SaveAs(newPathFileName);


                //Now read excel file into database

                FileInfo eFile = new FileInfo(newPathFileName);
                using(var excelPackage = new ExcelPackage(eFile))
                {
                    var worksheet = excelPackage.Workbook.Worksheets[1];

                    var lastRow = worksheet.Dimension.End.Row;

                    using (var transactionRepository = new TransactionImportRepository())
                    {
                        for (var row = 2; row <= lastRow; row++)
                        {
                            try
                            {

                                TransactionData.ImportTransaction newImportTransaction = new TransactionData.ImportTransaction
                                {
                                    Id = 0,
                                    Account = worksheet.Cells[row, 1].Value.ToString(),
                                    Description = worksheet.Cells[row, 2].Value.ToString(),
                                    CurrencyCode = worksheet.Cells[row, 3].Value.ToString(),
                                    Amount = Convert.ToDecimal(worksheet.Cells[row, 4].Value),
                                    DateImported = DateTime.Today.Date
                                };
                                transactionRepository.Save(newImportTransaction);
                                //rowsImported += 1;
                            }
                            catch(Exception ex)
                            {
                                string Account = worksheet.Cells[row, 1].Value == null ? "Null value found" : worksheet.Cells[row, 1].Value.ToString();
                                string Description = worksheet.Cells[row, 2].Value == null ? "Null value found" : worksheet.Cells[row, 2].Value.ToString();
                                string CurrencyCode = worksheet.Cells[row, 3].Value == null ? "Null value found" : worksheet.Cells[row, 3].Value.ToString();
                                string Amount = worksheet.Cells[row, 4].Value == null ? "Null value found" : worksheet.Cells[row, 4].Value.ToString();
                                string Error = ex.Message + " Excel row " + rowsImported;
                                DateTime DateCreated = DateTime.Today.Date;

                                //Log error        
                                TransactionData.ErrorLog newError = new TransactionData.ErrorLog
                                {
                                    Id = 0,
                                    Account = Account,
                                    Description = Description,
                                    CurrencyCode = CurrencyCode,
                                    Amount = Amount,
                                    Error = Error,
                                    DateCreated = DateCreated
                                };
                                transactionRepository.Save(newError);
                                errorsImported += 1;
                            }
                            rowsImported += 1;
                        }
                    }

                    
                    ViewBag.RowsImported = rowsImported - errorsImported - 1;
                    ViewBag.ErrorsImported = errorsImported;
                    
                }
            }
            
            return View();
        }


        [HttpGet]
        public ActionResult Transactions()
        {
            Transaction transactionModel = new Transaction { Transactions = new List<TransactionRecord>() };

            try
            {
                
                IList<TransactionData.ImportTransaction> importTransactions = new List<TransactionData.ImportTransaction>();
                
                using(var transactionRepository = new TransactionImportRepository())
                {
                    importTransactions = transactionRepository.GetAllImportTransactions();

                    foreach(var importTransaction in importTransactions)
                    {
                        transactionModel.Transactions.Add(new TransactionRecord
                        {
                            Id = importTransaction.Id,
                            Account = importTransaction.Account,
                            Description = importTransaction.Description,
                            CurrencyCode = importTransaction.CurrencyCode,
                            Amount = importTransaction.Amount.ToString(),
                            DateImported = importTransaction.DateImported
                        });
                    }

                    transactionModel.CurrentPage = 1;
                    transactionModel.TotalNumberFound = transactionModel.Transactions.Count;

                    //100 rows per page
                    transactionModel.LastPage = (int)Math.Ceiling((double)transactionModel.Transactions.Count / 100);

                    transactionModel.Transactions = transactionModel.Transactions.OrderBy(ob => ob.Id).Take(100).ToList();
                    
                }


            }
            catch(Exception ex)
            {
                throw ex;
            }

            return View(transactionModel);
        }

        [HttpPost]
        public ActionResult Transactions(int pageNumber)
        {
            Transaction transactionModel = new Transaction { Transactions = new List<TransactionRecord>() };

            try
            {
                transactionModel.CurrentPage = pageNumber;


                IList<TransactionData.ImportTransaction> importTransactions = new List<TransactionData.ImportTransaction>();

                using (var transactionRepository = new TransactionImportRepository())
                {
                    importTransactions = transactionRepository.GetAllImportTransactions();

                    foreach (var importTransaction in importTransactions)
                    {
                        transactionModel.Transactions.Add(new TransactionRecord
                        {
                            Id = importTransaction.Id,
                            Account = importTransaction.Account,
                            Description = importTransaction.Description,
                            CurrencyCode = importTransaction.CurrencyCode,
                            Amount = importTransaction.Amount.ToString(),
                            DateImported = importTransaction.DateImported
                        });
                    }

                    transactionModel.TotalNumberFound = transactionModel.Transactions.Count;

                    //100 rows per page
                    transactionModel.LastPage = (int)Math.Ceiling((double)transactionModel.Transactions.Count / 100);

                    if (transactionModel.LastPage >= pageNumber)
                    {
                        transactionModel.Transactions = transactionModel.Transactions.OrderBy(ob => ob.Id).Skip((pageNumber - 1) * 100).Take(100).ToList();
                    }
                    else
                    {
                        transactionModel.Transactions = transactionModel.Transactions.OrderBy(ob => ob.Id).Skip((transactionModel.LastPage - 1) * 100).Take(100).ToList();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PartialView("_TransactionsPartial", transactionModel);
        }


        public ActionResult ErrorLog()
        {
            Error errorModel = new Error { Errors = new List<ErrorRecord>() };

            try
            {

                IList<TransactionData.ErrorLog> errorLogs = new List<TransactionData.ErrorLog>();

                using (var transactionRepository = new TransactionImportRepository())
                {
                    errorLogs = transactionRepository.GetAllErrorLogs();

                    foreach (var errorLog in errorLogs)
                    {
                        errorModel.Errors.Add(new ErrorRecord
                        {
                            Id = errorLog.Id,
                            Account = errorLog.Account.ToString(),
                            Description = errorLog.Description.ToString(),
                            CurrencyCode = errorLog.CurrencyCode.ToString(),
                            Amount = errorLog.Amount,
                            DateImported = errorLog.DateCreated,
                            Error = errorLog.Error
                        });
                    }

                    errorModel.CurrentPage = 1;
                    errorModel.TotalNumberFound = errorModel.Errors.Count;

                    //100 rows per page
                    errorModel.LastPage = (int)Math.Ceiling((double)errorModel.Errors.Count / 100);

                    errorModel.Errors = errorModel.Errors.OrderBy(ob => ob.Id).Take(100).ToList();

                }


            }
            catch (Exception ex)
            {
                throw ex;
            }

            return View(errorModel);
        }

        [HttpPost]
        public ActionResult ErrorLog(int pageNumber)
        {
            Error errorModel = new Error { Errors = new List<ErrorRecord>() };

            try
            {
                errorModel.CurrentPage = pageNumber;


                IList<TransactionData.ErrorLog> errorLogs = new List<TransactionData.ErrorLog>();

                using (var transactionRepository = new TransactionImportRepository())
                {
                    errorLogs = transactionRepository.GetAllErrorLogs();

                    foreach (var errorLog in errorLogs)
                    {
                        errorModel.Errors.Add(new ErrorRecord
                        {
                            Id = errorLog.Id,
                            Account = errorLog.Account,
                            Description = errorLog.Description,
                            CurrencyCode = errorLog.CurrencyCode,
                            Amount = errorLog.Amount.ToString(),
                            DateImported = errorLog.DateCreated,
                            Error = errorLog.Error
                        });
                    }

                    errorModel.TotalNumberFound = errorModel.Errors.Count;

                    //100 rows per page
                    errorModel.LastPage = (int)Math.Ceiling((double)errorModel.Errors.Count / 100);

                    if (errorModel.LastPage >= pageNumber)
                    {
                        errorModel.Errors = errorModel.Errors.OrderBy(ob => ob.Id).Skip((pageNumber - 1) * 100).Take(100).ToList();
                    }
                    else
                    {
                        errorModel.Errors = errorModel.Errors.OrderBy(ob => ob.Id).Skip((errorModel.LastPage - 1) * 100).Take(100).ToList();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PartialView("_ErrorLogPartial", errorModel);
        }

    }
}